package com.javaguides.javafx.login.repository.helpers;

public class JDBCConstants {
    public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
    public static final String URL         = "jdbc:mysql://localhost:3306/javafx?useSSL=false";
    public static final String USERNAME    = "root";
    public static final String PASSWORD    = "password";
}
