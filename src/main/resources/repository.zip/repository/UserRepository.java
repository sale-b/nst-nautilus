/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaguides.javafx.login.repository;


import com.javaguides.javafx.login.domain.User;
import com.javaguides.javafx.login.repository.helpers.JDBCHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author laptop-02
 */
public class UserRepository {

    public static final String SELECT_ALL_SQL_QUERY = "SELECT ID,FIRST_NAME,LAST_NAME,USERNAME,PASSWORD FROM USER";
    private static final String SELECT_EMAIL_PASS_QUERY = "SELECT * FROM user WHERE email = ? and password = ?";


    public List<User> getAll() throws Exception {
        {
            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            List<User> users = new ArrayList<>();
            try {
                con = JDBCHelper.getConnection();
                if (con == null) {
                    throw new SQLException("Error getting the connection. Please check if the DB server is running");
                }
                ps = con.prepareStatement(SELECT_ALL_SQL_QUERY);
                rs = ps.executeQuery();
                System.out.println("retriveUsers => " + ps.toString());
                while (rs.next()) {
                    User u = new User();
                    u.setId(rs.getLong("ID"));
                    u.setFirstname(rs.getString("FIRST_NAME"));
                    u.setLastname(rs.getString("LAST_NAME"));
                    u.setEmail(rs.getString("EMAIL"));
                    u.setPassword(rs.getString("PASSWORD"));
                    users.add(u);

                }

            } catch (SQLException e) {
                throw e;

            } finally {
                try {
                    JDBCHelper.closeResultSet(rs);
                    JDBCHelper.closePrepaerdStatement(ps);
                    JDBCHelper.closeConnection(con);
                } catch (SQLException e) {
                    throw e;
                }
            }
            return users;
        }
    }

    public Optional<User> getByEmailandPass(String email, String pass) throws Exception {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User u = new User();
        try {
            con = JDBCHelper.getConnection();
            if (con == null) {
                throw new SQLException("Error getting the connection. Please check if the DB server is running");
            }
            ps = con.prepareStatement(SELECT_EMAIL_PASS_QUERY);
            ps.setString(1, email);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            System.out.println("retriveUser => " + ps.toString());
            if (rs.next()) {
                u.setId(rs.getLong("ID"));
                u.setFirstname(rs.getString("FIRST_NAME"));
                u.setLastname(rs.getString("LAST_NAME"));
                u.setEmail(rs.getString("EMAIL"));
                u.setPassword(rs.getString("PASSWORD"));
            } else {
                u = null;
            }
        } catch (SQLException e) {
            throw e;

        } finally {
            try {
                JDBCHelper.closeResultSet(rs);
                JDBCHelper.closePrepaerdStatement(ps);
                JDBCHelper.closeConnection(con);
            } catch (SQLException e) {
                throw e;
            }
        }
        return Optional.ofNullable(u);
    }

}
